
require('../../../images/side_bag.svg');
require('../../../images/side_bigBag.svg');
require('../../../images/side_cacheOnDelivery.svg');
require('../../../images/side_delivery.svg');
require('../../../images/side_info.svg');
require('../../../images/side_list.svg');
require('../../../images/side_menu.svg');
require('../../../images/side_pickup.svg');
require('../../../images/side_watch.svg');

require('../../../images/side_pin_delivery.svg');
require('../../../images/side_pin_failed.svg');
require('../../../images/side_pin_pickup.svg');
require('../../../images/side_pin_succeeded.svg');
require('../../../images/side_pin_unassigned.svg');

require('../../../images/side_id_red.svg');
require('../../../images/side_id_violet.svg');
require('../../../images/side_id_blue.svg');

// todo replace with svg sometime
require('../../../images/mot.png');
require('../../../images/sed.png');
require('../../../images/suv.png');
require('../../../images/van.png');
require('../../../images/title.png');
require('../../../images/title1.png');
